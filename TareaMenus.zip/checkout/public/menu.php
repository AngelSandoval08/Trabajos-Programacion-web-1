<ul class="navbar-nav me-auto mb-2 mb-md-0">
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" aria-expanded="false">Categorias</a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="supermercado.php">Supermercado</a></li>
              <li><a class="dropdown-item" href="belleza.php">Belleza y cuidado personal</a></li>
              <li><a class="dropdown-item" href="tecnologia.php">Tecnologia</a></li>
              <li><a class="dropdown-item" href="prendas.php">Prendas y calzado</a></li> 
              <li><a class="dropdown-item" href="salud.php">Salud</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="inicio.php">Inicio</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="ofertas.php">Ofertas</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="vender.php">Vender</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="soporte.php">Soporte</a>
          </li>
          
        </ul>