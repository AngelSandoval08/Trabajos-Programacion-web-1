<ul class="navbar-nav me-auto mb-2 mb-md-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Inicio</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="paquetes.php">Paquetes</a>
          </li>
          <li class="nav-item">
            <a class="nav-link " href="vuelos.php">Vuelos</a>
          </li>
          <li class="nav-item"></li>
            <a class="nav-link" href="hoteles.php">Hoteles</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="ofertas.php">Ofertas</a>
          </li>
        </ul>