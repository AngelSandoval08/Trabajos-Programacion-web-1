<nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="caracteristicas.php">Caracteristicas</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="empresa.php">Empresa</a>
        <a class="me-3 py-2 link-body-emphasis text-decoration-none" href="soporte.php">Soporte</a>
        <a class="py-2 link-body-emphasis text-decoration-none" href="precios.php">Precios</a>
      </nav>