<ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page" href="inicio.php">
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                Inicio
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="mascotas.php">
                <svg class="bi"><use xlink:href="#file-earmark"/></svg>
                Mascotas
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="productos.php">
                <svg class="bi"><use xlink:href="#cart"/></svg>
                Productos
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="clientes.php">
                <svg class="bi"><use xlink:href="#people"/></svg>
                Clientes
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="servicios.php">
                <svg class="bi"><use xlink:href="#graph-up"/></svg>
                Servicios
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="veterinarios.php">
                <svg class="bi"><use xlink:href="#puzzle"/></svg>
                Veterinarios
              </a>
            </li>
          </ul>